'use strict';

var _env = require('./env');

var _env2 = _interopRequireDefault(_env);

var _express = require('./express');

var _express2 = _interopRequireDefault(_express);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// eslint-disable-line

process.env.NODE_ENV = process.env.NODE_ENV || 'local'; // eslint-disable-line
//# sourceMappingURL=index.js.map