'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _http = require('http');

var _http2 = _interopRequireDefault(_http);

var _express = require('express');

var _express2 = _interopRequireDefault(_express);

var _cors = require('cors');

var _cors2 = _interopRequireDefault(_cors);

var _bodyParser = require('body-parser');

var _bodyParser2 = _interopRequireDefault(_bodyParser);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _chalk = require('chalk');

var _chalk2 = _interopRequireDefault(_chalk);

var _consolidate = require('consolidate');

var _consolidate2 = _interopRequireDefault(_consolidate);

var _webpack = require('webpack');

var _webpack2 = _interopRequireDefault(_webpack);

var _compression = require('compression');

var _compression2 = _interopRequireDefault(_compression);

var _serveFavicon = require('serve-favicon');

var _serveFavicon2 = _interopRequireDefault(_serveFavicon);

var _herokuSslRedirect = require('heroku-ssl-redirect');

var _herokuSslRedirect2 = _interopRequireDefault(_herokuSslRedirect);

var _config = require('./config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ISPROD = process.env.NODE_ENV === 'production';

var app = (0, _express2.default)();
app.use((0, _herokuSslRedirect2.default)());
app.use((0, _compression2.default)());
app.use((0, _serveFavicon2.default)(_path2.default.join(__dirname, '../public', 'favicon.ico')));

if (!ISPROD) {
  var compiler = (0, _webpack2.default)(require('../webpack.config'));
  app.use(require('webpack-dev-middleware')(compiler, {
    publicPath: '/public/',
    hot: true
  }));

  app.use(require('webpack-hot-middleware')(compiler, {
    reload: true
  }));
}

var initRoutes = function initRoutes(appVariable, publicPath) {
  var assets = {};
  if (ISPROD) {
    assets = require('../build/assets.json');
  }

  appVariable.use('/public', _express2.default.static(publicPath, { maxage: '30 days' }));
  appVariable.use(_express2.default.static(_path2.default.join(__dirname, '../public/resources'), { maxAge: 864000000 }));
  appVariable.route('*').get(function (req, res) {
    return res.render('index', assets);
  });
};

var initMiddlewares = function initMiddlewares(appVariable) {
  // 3rd party middleware
  appVariable.use((0, _cors2.default)({
    exposedHeaders: ['Link']
  }));
  appVariable.use(_bodyParser2.default.json({
    limit: '100kb'
  }));
};

var initTemplateEngine = function initTemplateEngine(appVariable) {
  appVariable.engine('html', _consolidate2.default.swig);
  appVariable.set('views', _path2.default.resolve('./server/views'));
  appVariable.set('view engine', 'html');
};

var port = process.env.PORT || _config2.default.port;
var frontPath = _path2.default.resolve(__dirname, '../build');

app.server = _http2.default.createServer(app);

initMiddlewares(app);
initTemplateEngine(app);
initRoutes(app, frontPath);

// start listening
app.server.listen(port);
console.log(_chalk2.default.green('Express started on port ' + port + ', path: ' + frontPath));
exports.default = app;
//# sourceMappingURL=express.js.map