'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dotenv = require('dotenv');

var _dotenv2 = _interopRequireDefault(_dotenv);

var _default = require('./env/default');

var _default2 = _interopRequireDefault(_default);

var _local = require('./env/local');

var _local2 = _interopRequireDefault(_local);

var _development = require('./env/development');

var _development2 = _interopRequireDefault(_development);

var _prod = require('./env/prod');

var _prod2 = _interopRequireDefault(_prod);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_dotenv2.default.config({ silent: true });

var config = Object.assign({}, _default2.default);

switch (process.env.NODE_ENV) {
  case 'local':
    Object.assign(config, _local2.default);
    break;
  case 'development':
    Object.assign(config, _development2.default);
    break;
  case 'production':
    Object.assign(config, _prod2.default);
    break;
  default:
    break;
}

exports.default = config;
//# sourceMappingURL=index.js.map