'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  port: process.env.PORT || 8080,
  apiURL: process.env.API_URL || 'http://localhost:3000'
};
//# sourceMappingURL=default.js.map